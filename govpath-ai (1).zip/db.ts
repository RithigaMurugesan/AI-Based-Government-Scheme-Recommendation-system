import Database from 'better-sqlite3';
import path from 'path';

const db = new Database('govpath.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    age INTEGER,
    gender TEXT,
    education TEXT,
    field_of_study TEXT,
    occupation TEXT,
    annual_income REAL,
    state TEXT,
    category TEXT,
    disability_status INTEGER,
    interests TEXT
  );

  CREATE TABLE IF NOT EXISTS schemes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    benefits TEXT,
    application_link TEXT,
    eligibility_rules TEXT -- JSON string of rules
  );

  CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    qualification_required TEXT,
    max_age INTEGER,
    category TEXT,
    application_link TEXT
  );
`);

// Seed data if empty
const schemeCount = db.prepare('SELECT count(*) as count FROM schemes').get() as { count: number };
if (schemeCount.count === 0) {
  const insertScheme = db.prepare(`
    INSERT INTO schemes (name, description, benefits, application_link, eligibility_rules)
    VALUES (?, ?, ?, ?, ?)
  `);

  // 1. Farmer / Agriculture Schemes
  insertScheme.run('Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)', 'Income support to all landholding farmers families.', 'Rs. 6000 per year in three installments.', 'https://pmkisan.gov.in/', JSON.stringify({ occupation: 'Farmer' }));
  insertScheme.run('Pradhan Mantri Fasal Bima Yojana (PMFBY)', 'Insurance service for farmers for their yields.', 'Financial support to farmers suffering crop loss.', 'https://pmfby.gov.in/', JSON.stringify({ occupation: 'Farmer' }));
  insertScheme.run('Pradhan Mantri Krishi Sinchai Yojana (PMKSY)', 'Focus on improving water use efficiency.', 'Subsidies for micro-irrigation systems.', 'https://pmksy.gov.in/', JSON.stringify({ occupation: 'Farmer' }));
  insertScheme.run('Soil Health Card Scheme', 'Provides information to farmers on nutrient status of their soil.', 'Optimized use of fertilizers.', 'https://soilhealth.dac.gov.in/', JSON.stringify({ occupation: 'Farmer' }));
  insertScheme.run('Kisan Credit Card (KCC)', 'Provides adequate and timely credit support from the banking system.', 'Short term credit for cultivation of crops.', 'https://www.myscheme.gov.in/schemes/kcc', JSON.stringify({ occupation: 'Farmer' }));

  // 2. Student / Scholarship Schemes
  insertScheme.run('National Means Cum Merit Scholarship', 'Scholarship for meritorious students of economically weaker sections.', 'Rs. 12000 per annum.', 'https://scholarships.gov.in/', JSON.stringify({ education: 'Below 10th', maxIncome: 350000 }));
  insertScheme.run('AICTE Pragati Scholarship for Girls', 'Scholarship for girls pursuing technical education.', 'Rs. 50,000 per annum.', 'https://www.aicte-india.org/schemes/students-development-schemes/pragati', JSON.stringify({ gender: 'Female', education: 'Graduate' }));
  insertScheme.run('Post Matric Scholarship for SC Students', 'Scholarship for SC students for higher education.', 'Full tuition fee waiver.', 'https://scholarships.gov.in/', JSON.stringify({ category: ['SC'], education: 'Graduate' }));
  insertScheme.run('Post Matric Scholarship for ST Students', 'Scholarship for ST students for higher education.', 'Full tuition fee waiver.', 'https://scholarships.gov.in/', JSON.stringify({ category: ['ST'], education: 'Graduate' }));

  // 3. Women Welfare Schemes
  insertScheme.run('Beti Bachao Beti Padhao', 'Ensuring survival, protection and education of the girl child.', 'Social awareness and education support.', 'https://wcd.nic.in/bbbp-schemes', JSON.stringify({ gender: 'Female' }));
  insertScheme.run('Sukanya Samriddhi Yojana', 'Small deposit scheme for the girl child.', 'High interest rate and tax benefits.', 'https://www.nsiindia.gov.in/', JSON.stringify({ gender: 'Female', age: 10 }));
  insertScheme.run('Pradhan Mantri Matru Vandana Yojana', 'Maternity benefit program.', 'Cash incentive of Rs. 5000.', 'https://wcd.nic.in/schemes/pradhan-mantri-matru-vandana-yojana', JSON.stringify({ gender: 'Female' }));

  // 4. Employment / Skill Development
  insertScheme.run('Pradhan Mantri Kaushal Vikas Yojana (PMKVY)', 'Skill certification scheme to enable youth to take up industry-relevant skill training.', 'Skill training and certification.', 'https://www.pmkvyofficial.org/', JSON.stringify({ education: '12th Pass (HSC)' }));
  insertScheme.run('Startup India Scheme', 'Promotion of startups, generation of employment, and wealth creation.', 'Tax exemptions and funding support.', 'https://www.startupindia.gov.in/', JSON.stringify({ occupation: 'Entrepreneur' }));

  // 5. Health Schemes
  insertScheme.run('Ayushman Bharat (PM-JAY)', 'Health insurance cover of Rs. 5 lakhs per family per year.', 'Cashless treatment in empaneled hospitals.', 'https://pmjay.gov.in/', JSON.stringify({ maxIncome: 250000 }));
  insertScheme.run('Jan Aushadhi Scheme', 'Making quality medicines available at affordable prices.', 'Generic medicines at low cost.', 'http://janaushadhi.gov.in/', JSON.stringify({}));

  // 6. Housing Schemes
  insertScheme.run('Pradhan Mantri Awas Yojana – Urban', 'Housing for all in urban areas.', 'Subsidy on home loan interest.', 'https://pmaymis.gov.in/', JSON.stringify({ maxIncome: 1800000 }));
  insertScheme.run('Pradhan Mantri Awas Yojana – Rural', 'Housing for all in rural areas.', 'Financial assistance for house construction.', 'https://pmayg.nic.in/', JSON.stringify({ state: 'Rural' }));

  // 7. Pension / Social Security
  insertScheme.run('Atal Pension Yojana', 'Pension scheme for citizens in the unorganized sector.', 'Guaranteed minimum pension.', 'https://www.npscra.nsdl.co.in/scheme-details.php', JSON.stringify({ age: 40 }));
  insertScheme.run('National Pension System (NPS)', 'Voluntary defined contribution pension system.', 'Old age income security.', 'https://www.npscra.nsdl.co.in/', JSON.stringify({ age: 60 }));

  // 8. Financial Inclusion
  insertScheme.run('Pradhan Mantri Jan Dhan Yojana', 'National Mission for Financial Inclusion.', 'Bank account with zero balance.', 'https://pmjdy.gov.in/', JSON.stringify({}));
  insertScheme.run('Pradhan Mantri Mudra Yojana', 'Providing loans up to 10 lakh to non-corporate, non-farm small/micro enterprises.', 'Loans for small businesses.', 'https://www.mudra.org.in/', JSON.stringify({ occupation: 'Entrepreneur' }));
}

const examCount = db.prepare('SELECT count(*) as count FROM exams').get() as { count: number };
if (examCount.count === 0) {
  const insertExam = db.prepare(`
    INSERT INTO exams (name, description, qualification_required, max_age, category, application_link)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  insertExam.run('UPSC Civil Services Examination', 'Premier exam for IAS, IPS, IFS.', 'Graduate', 32, 'Civil Services', 'https://upsc.gov.in/');
  insertExam.run('SSC CGL', 'Staff Selection Commission - Combined Graduate Level.', 'Graduate', 30, 'General', 'https://ssc.nic.in/');
  insertExam.run('SSC CHSL', 'Staff Selection Commission - Combined Higher Secondary Level.', '12th Pass (HSC)', 27, 'General', 'https://ssc.nic.in/');
  insertExam.run('IBPS PO', 'Probationary Officers in public sector banks.', 'Graduate', 30, 'Banking', 'https://ibps.in/');
  insertExam.run('IBPS Clerk', 'Clerical cadre in public sector banks.', 'Graduate', 28, 'Banking', 'https://ibps.in/');
  insertExam.run('SBI PO', 'Probationary Officers in State Bank of India.', 'Graduate', 30, 'Banking', 'https://sbi.co.in/');
  insertExam.run('RBI Grade B', 'Officers in Grade B in Reserve Bank of India.', 'Graduate', 30, 'Banking', 'https://rbi.org.in/');
  insertExam.run('Railway Recruitment Board Exams', 'Various posts in Indian Railways.', '10th Pass (SSLC)', 33, 'Railway', 'https://indianrailways.gov.in/');
  insertExam.run('NDA (National Defence Academy)', 'Entrance for Army, Navy, and Air Force.', '12th Pass (HSC)', 19, 'Defence', 'https://upsc.gov.in/');
  insertExam.run('CDS (Combined Defence Services)', 'Entrance for commissioned officers in the Armed Forces.', 'Graduate', 24, 'Defence', 'https://upsc.gov.in/');
  insertExam.run('State Public Service Commission Exams', 'Administrative services at the state level.', 'Graduate', 37, 'State Services', 'https://tnpsc.gov.in/');
  insertExam.run('UGC NET', 'Eligibility for Assistant Professor and Junior Research Fellowship.', 'Post Graduate', 30, 'Education', 'https://ugcnet.nta.nic.in/');
  insertExam.run('GATE', 'Graduate Aptitude Test in Engineering for higher studies and PSUs.', 'Graduate', 99, 'Engineering', 'https://gate.iitk.ac.in/');
}

export default db;
