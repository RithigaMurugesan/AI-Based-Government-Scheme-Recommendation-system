# GovPath AI - Java Spring Boot Starter

This folder contains the backend starter code for the Government Scheme and Exam Recommendation System.

## Prerequisites
- Java 17 or higher
- Maven 3.6+
- MySQL 8.0+

## Setup Instructions

1. **Database Setup**:
   - Run the `database.sql` script in your MySQL instance to create the schema and seed data.
   - Update `src/main/resources/application.properties` with your MySQL credentials:
     ```properties
     spring.datasource.url=jdbc:mysql://localhost:3306/govpath_db
     spring.datasource.username=your_username
     spring.datasource.password=your_password
     spring.jpa.hibernate.ddl-auto=update
     ```

2. **Project Structure**:
   - Create a new Spring Boot project using [Spring Initializr](https://start.spring.io/).
   - Add dependencies: `Spring Web`, `Spring Data JPA`, `MySQL Driver`, `Lombok`.
   - Copy the provided Controller and Service classes into your project.

3. **Running the App**:
   - Run `mvn spring-boot:run` in the project root.
   - The API will be available at `http://localhost:8080/api/recommend`.

## Recommendation Algorithm
The core logic resides in `RecommendationService.java`. It uses Java Streams to filter schemes and exams based on the user's profile attributes (Age, Income, Education, etc.).
