-- Database Creation Script for MySQL
CREATE DATABASE IF NOT EXISTS govpath_db;
USE govpath_db;

-- Users Table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT,
    gender ENUM('Male', 'Female', 'Other'),
    education VARCHAR(100),
    occupation VARCHAR(100),
    income DECIMAL(15, 2),
    state VARCHAR(50),
    category VARCHAR(20),
    disability_status BOOLEAN DEFAULT FALSE,
    interest TEXT
);

-- Government Schemes Table
CREATE TABLE government_schemes (
    scheme_id INT AUTO_INCREMENT PRIMARY KEY,
    scheme_name VARCHAR(255) NOT NULL,
    description TEXT,
    eligibility_rules JSON, -- Store complex rules as JSON
    benefits TEXT,
    application_link VARCHAR(255)
);

-- Government Exams Table
CREATE TABLE government_exams (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_name VARCHAR(255) NOT NULL,
    qualification_required VARCHAR(100),
    age_limit INT,
    exam_description TEXT,
    application_link VARCHAR(255)
);

-- Recommendations Table (History)
CREATE TABLE recommendations (
    recommendation_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    scheme_id INT,
    exam_id INT,
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Admin Table
CREATE TABLE admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Sample Data
-- Farmer / Agriculture Schemes
INSERT INTO government_schemes (scheme_name, description, benefits, application_link, eligibility_rules)
VALUES 
('Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)', 'Income support to all landholding farmers families.', 'Rs. 6000 per year in three installments.', 'https://pmkisan.gov.in/', '{"occupation": "Farmer"}'),
('Pradhan Mantri Fasal Bima Yojana (PMFBY)', 'Insurance service for farmers for their yields.', 'Financial support to farmers suffering crop loss.', 'https://pmfby.gov.in/', '{"occupation": "Farmer"}'),
('Pradhan Mantri Krishi Sinchai Yojana (PMKSY)', 'Focus on improving water use efficiency.', 'Subsidies for micro-irrigation systems.', 'https://pmksy.gov.in/', '{"occupation": "Farmer"}'),
('Soil Health Card Scheme', 'Provides information to farmers on nutrient status of their soil.', 'Optimized use of fertilizers.', 'https://soilhealth.dac.gov.in/', '{"occupation": "Farmer"}'),
('Kisan Credit Card (KCC)', 'Provides adequate and timely credit support from the banking system.', 'Short term credit for cultivation of crops.', 'https://www.myscheme.gov.in/schemes/kcc', '{"occupation": "Farmer"}');

-- Student / Scholarship Schemes
INSERT INTO government_schemes (scheme_name, description, benefits, application_link, eligibility_rules)
VALUES 
('National Means Cum Merit Scholarship', 'Scholarship for meritorious students of economically weaker sections.', 'Rs. 12000 per annum.', 'https://scholarships.gov.in/', '{"education": "Below 10th", "maxIncome": 350000}'),
('AICTE Pragati Scholarship for Girls', 'Scholarship for girls pursuing technical education.', 'Rs. 50,000 per annum.', 'https://www.aicte-india.org/schemes/students-development-schemes/pragati', '{"gender": "Female", "education": "Graduate"}'),
('Post Matric Scholarship for SC Students', 'Scholarship for SC students for higher education.', 'Full tuition fee waiver.', 'https://scholarships.gov.in/', '{"category": ["SC"], "education": "Graduate"}');

-- Major Government Exams
INSERT INTO government_exams (exam_name, qualification_required, age_limit, exam_description, application_link)
VALUES 
('UPSC Civil Services Examination', 'Graduate', 32, 'Exam for IAS/IPS', 'https://upsc.gov.in'),
('SSC CGL', 'Graduate', 30, 'Staff Selection Commission - Combined Graduate Level', 'https://ssc.nic.in'),
('SSC CHSL', '12th Pass (HSC)', 27, 'Staff Selection Commission - Combined Higher Secondary Level', 'https://ssc.nic.in'),
('IBPS PO', 'Graduate', 30, 'Probationary Officers in public sector banks', 'https://ibps.in'),
('Railway Recruitment Board Exams', '10th Pass (SSLC)', 33, 'Various posts in Indian Railways', 'https://indianrailways.gov.in'),
('NDA (National Defence Academy)', '12th Pass (HSC)', 19, 'Entrance for Army, Navy, and Air Force', 'https://upsc.gov.in'),
('CDS (Combined Defence Services)', 'Graduate', 24, 'Entrance for commissioned officers in the Armed Forces', 'https://upsc.gov.in'),
('UGC NET', 'Post Graduate', 30, 'Eligibility for Assistant Professor and JRF', 'https://ugcnet.nta.nic.in'),
('GATE', 'Graduate', 99, 'Graduate Aptitude Test in Engineering', 'https://gate.iitk.ac.in');
