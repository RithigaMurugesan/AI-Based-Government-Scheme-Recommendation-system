package com.govpath.model;

import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "government_exams")
public class Exam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "exam_name")
    private String name;

    private String description;

    @Column(name = "qualification_required")
    private String qualificationRequired;

    @Column(name = "age_limit")
    private Integer ageLimit;

    private String category;

    @Column(name = "application_link")
    private String applicationLink;
}
