package com.govpath.model;

import lombok.Data;
import java.util.List;

@Data
public class User {
    private Long id;
    private String name;
    private Integer age;
    private String gender;
    private String education;
    private String occupation;
    private Double income;
    private String state;
    private String category;
    private Boolean disabilityStatus;
    private List<String> interests;
}
