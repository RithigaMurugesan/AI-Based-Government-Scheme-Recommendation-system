package com.govpath.controller;

import com.govpath.model.User;
import com.govpath.model.RecommendationResponse;
import com.govpath.service.RecommendationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class RecommendationController {

    @Autowired
    private RecommendationService recommendationService;

    @PostMapping("/recommend")
    public ResponseEntity<RecommendationResponse> getRecommendations(@RequestBody User user) {
        RecommendationResponse response = recommendationService.generateRecommendations(user);
        return ResponseEntity.ok(response);
    }
}
