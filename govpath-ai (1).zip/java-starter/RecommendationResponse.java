package com.govpath.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class RecommendationResponse {
    private List<Scheme> schemes;
    private List<Exam> exams;
    private String advice;
}
