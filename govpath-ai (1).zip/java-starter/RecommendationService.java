package com.govpath.service;

import com.govpath.model.User;
import com.govpath.model.Scheme;
import com.govpath.model.Exam;
import com.govpath.model.RecommendationResponse;
import com.govpath.repository.SchemeRepository;
import com.govpath.repository.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RecommendationService {

    @Autowired
    private SchemeRepository schemeRepository;

    @Autowired
    private ExamRepository examRepository;

    public RecommendationResponse generateRecommendations(User user) {
        // 1. Fetch all schemes and exams from database
        List<Scheme> allSchemes = schemeRepository.findAll();
        List<Exam> allExams = examRepository.findAll();

        // 2. Filter Schemes based on eligibility rules
        List<Scheme> recommendedSchemes = allSchemes.stream()
                .filter(scheme -> isEligibleForScheme(user, scheme))
                .collect(Collectors.toList());

        // 3. Filter Exams based on qualification and age
        List<Exam> recommendedExams = allExams.stream()
                .filter(exam -> isEligibleForExam(user, exam))
                .collect(Collectors.toList());

        // 4. Return combined response
        return new RecommendationResponse(recommendedSchemes, recommendedExams, "Keep studying hard!");
    }

    private boolean isEligibleForScheme(User user, Scheme scheme) {
        // Example logic: Income check
        if (scheme.getMaxIncome() != null && user.getIncome() > scheme.getMaxIncome()) {
            return false;
        }
        // Category check
        if (scheme.getRequiredCategory() != null && !scheme.getRequiredCategory().equals(user.getCategory())) {
            return false;
        }
        return true;
    }

    private boolean isEligibleForExam(User user, Exam exam) {
        // Age check
        if (user.getAge() > exam.getAgeLimit()) {
            return false;
        }
        // Qualification check (simplified)
        if (!user.getEducation().equalsIgnoreCase(exam.getQualificationRequired())) {
            return false;
        }
        return true;
    }
}
