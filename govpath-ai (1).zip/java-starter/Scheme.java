package com.govpath.model;

import lombok.Data;
import javax.persistence.*;

@Data
@Entity
@Table(name = "government_schemes")
public class Scheme {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "scheme_name")
    private String name;

    private String description;
    private String benefits;

    @Column(name = "application_link")
    private String applicationLink;

    @Column(name = "eligibility_rules")
    private String eligibilityRules; // JSON string

    // Helper methods for parsing rules
    public Double getMaxIncome() {
        // Implement JSON parsing logic (e.g., using Jackson)
        return null; 
    }

    public String getRequiredCategory() {
        // Implement JSON parsing logic
        return null;
    }
}
