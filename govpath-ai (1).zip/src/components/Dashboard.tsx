import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Sparkles, BookOpen, GraduationCap, ExternalLink, AlertCircle, Loader2, UserCircle } from "lucide-react";
import { motion } from "motion/react";

interface DashboardProps {
  profile: any;
}

export default function Dashboard({ profile }: DashboardProps) {
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (profile) {
      setLoading(true);
      fetch("/api/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile),
      })
        .then((res) => res.json())
        .then((data) => {
          setResults(data);
          setLoading(false);
        })
        .catch((err) => {
          console.error(err);
          setLoading(false);
        });
    }
  }, [profile]);

  if (!profile) {
    return (
      <div className="text-center py-20">
        <div className="bg-white p-12 rounded-3xl shadow-sm border border-slate-200 max-w-xl mx-auto">
          <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <UserCircle className="w-10 h-10 text-emerald-600" />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Welcome to GovPath AI</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            To see personalized government schemes and exam recommendations, please complete your profile first.
          </p>
          <Link
            to="/profile"
            className="inline-flex items-center gap-2 bg-emerald-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200"
          >
            Create Your Profile
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* AI Advice Header */}
      {results?.advice && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-3xl p-8 text-white shadow-xl shadow-emerald-100 relative overflow-hidden"
        >
          <div className="relative z-10 flex items-start gap-4">
            <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-sm">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1">AI Recommendation Summary</h3>
              <p className="text-emerald-50 text-lg leading-relaxed italic">"{results.advice}"</p>
            </div>
          </div>
          {/* Decorative circles */}
          <div className="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-emerald-400/20 rounded-full blur-3xl"></div>
        </motion.div>
      )}

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Loader2 className="w-10 h-10 text-emerald-600 animate-spin" />
          <p className="text-slate-500 font-medium">Analyzing eligibility rules...</p>
        </div>
      )}

      {!loading && results && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Schemes Section */}
          <section className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900">Recommended Schemes</h2>
            </div>
            
            <div className="space-y-4">
              {results.schemes.length > 0 ? (
                results.schemes.map((scheme: any) => (
                  <motion.div 
                    key={scheme.id}
                    whileHover={{ scale: 1.01 }}
                    className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all"
                  >
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{scheme.name}</h3>
                    <p className="text-slate-600 text-sm mb-4 line-clamp-2">{scheme.description}</p>
                    <div className="bg-blue-50 p-4 rounded-xl mb-4">
                      <p className="text-blue-800 text-sm font-medium">Benefits: {scheme.benefits}</p>
                    </div>
                    <a 
                      href={scheme.application_link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-emerald-600 font-bold hover:underline"
                    >
                      Apply Now <ExternalLink className="w-4 h-4" />
                    </a>
                  </motion.div>
                ))
              ) : (
                <div className="bg-slate-100 p-8 rounded-2xl text-center">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-slate-500">No matching schemes found for your profile.</p>
                </div>
              )}
            </div>
          </section>

          {/* Exams Section */}
          <section className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-2 rounded-lg">
                <GraduationCap className="w-5 h-5 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900">Government Exams</h2>
            </div>

            <div className="space-y-4">
              {results.exams.length > 0 ? (
                results.exams.map((exam: any) => (
                  <motion.div 
                    key={exam.id}
                    whileHover={{ scale: 1.01 }}
                    className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-slate-900">{exam.name}</h3>
                      <span className="bg-purple-100 text-purple-700 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                        {exam.category}
                      </span>
                    </div>
                    <p className="text-slate-600 text-sm mb-4">{exam.description}</p>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="bg-slate-50 p-3 rounded-xl">
                        <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Min. Qualification</p>
                        <p className="text-sm font-semibold text-slate-700">{exam.qualification_required}</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-xl">
                        <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Max Age</p>
                        <p className="text-sm font-semibold text-slate-700">{exam.max_age} Years</p>
                      </div>
                    </div>
                    <a 
                      href={exam.application_link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-emerald-600 font-bold hover:underline"
                    >
                      View Details <ExternalLink className="w-4 h-4" />
                    </a>
                  </motion.div>
                ))
              ) : (
                <div className="bg-slate-100 p-8 rounded-2xl text-center">
                  <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                  <p className="text-slate-500">No matching exams found for your profile.</p>
                </div>
              )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

