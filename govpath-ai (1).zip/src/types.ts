export enum Gender {
  MALE = "Male",
  FEMALE = "Female",
  OTHER = "Other"
}

export enum Category {
  GENERAL = "General",
  OBC = "OBC",
  SC = "SC",
  ST = "ST",
  EWS = "EWS"
}

export enum Education {
  BELOW_10TH = "Below 10th",
  SSLC = "10th Pass (SSLC)",
  HSC = "12th Pass (HSC)",
  DIPLOMA = "Diploma",
  GRADUATE = "Graduate",
  POST_GRADUATE = "Post Graduate",
  PHD = "PhD"
}

export interface UserProfile {
  id?: number;
  name: string;
  age: number;
  gender: Gender;
  education: Education;
  fieldOfStudy: string;
  occupation: string;
  annualIncome: number;
  state: string;
  category: Category;
  disabilityStatus: boolean;
  interests: string[];
}

export interface GovScheme {
  id: number;
  name: string;
  description: string;
  benefits: string;
  applicationLink: string;
  eligibilityCriteria: string; // JSON string for complex rules
}

export interface GovExam {
  id: number;
  name: string;
  description: string;
  qualificationRequired: Education;
  maxAge: number;
  category: string;
  applicationLink: string;
}
