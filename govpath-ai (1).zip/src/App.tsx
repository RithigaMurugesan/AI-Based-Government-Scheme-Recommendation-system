import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useState } from "react";
import Dashboard from "./components/Dashboard";
import ProfileForm from "./components/ProfileForm";
import AdminPanel from "./components/AdminPanel";
import { LayoutDashboard, UserCircle, Settings, Home } from "lucide-react";

export default function App() {
  const [userProfile, setUserProfile] = useState<any>(null);

  return (
    <Router>
      <div className="min-h-screen bg-slate-50 flex flex-col">
        {/* Navigation */}
        <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16 items-center">
              <div className="flex items-center gap-2">
                <div className="bg-emerald-600 p-2 rounded-lg">
                  <Home className="text-white w-5 h-5" />
                </div>
                <span className="font-bold text-xl text-slate-900 tracking-tight">GovPath AI</span>
              </div>
              
              <div className="hidden md:flex items-center space-x-8">
                <Link to="/" className="text-slate-600 hover:text-emerald-600 flex items-center gap-2 font-medium transition-colors">
                  <LayoutDashboard className="w-4 h-4" /> Dashboard
                </Link>
                <Link to="/profile" className="text-slate-600 hover:text-emerald-600 flex items-center gap-2 font-medium transition-colors">
                  <UserCircle className="w-4 h-4" /> Profile
                </Link>
                <Link to="/admin" className="text-slate-600 hover:text-emerald-600 flex items-center gap-2 font-medium transition-colors">
                  <Settings className="w-4 h-4" /> Admin
                </Link>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={<Dashboard profile={userProfile} />} />
            <Route path="/profile" element={<ProfileForm onSave={setUserProfile} initialData={userProfile} />} />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-slate-200 py-8">
          <div className="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
            &copy; 2026 GovPath AI. Empowering citizens through information.
          </div>
        </footer>
      </div>
    </Router>
  );
}
