import express from "express";
import { createServer as createViteServer } from "vite";
import db from "./db";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Routes ---

  // Get all schemes
  app.get("/api/schemes", (req, res) => {
    const schemes = db.prepare("SELECT * FROM schemes").all();
    res.json(schemes);
  });

  // Get all exams
  app.get("/api/exams", (req, res) => {
    const exams = db.prepare("SELECT * FROM exams").all();
    res.json(exams);
  });

  // Recommendation Engine Logic
  app.post("/api/recommend", async (req, res) => {
    const profile = req.body;
    
    // 1. Rule-based filtering for Schemes
    const allSchemes = db.prepare("SELECT * FROM schemes").all() as any[];
    const recommendedSchemes = allSchemes.filter(scheme => {
      const rules = JSON.parse(scheme.eligibility_rules);
      
      if (rules.maxIncome && profile.annualIncome > rules.maxIncome) return false;
      if (rules.category && rules.category.length > 0 && !rules.category.includes(profile.category)) return false;
      if (rules.occupation && profile.occupation.toLowerCase() !== rules.occupation.toLowerCase()) return false;
      
      return true;
    });

    // 2. Rule-based filtering for Exams
    const allExams = db.prepare("SELECT * FROM exams").all() as any[];
    const recommendedExams = allExams.filter(exam => {
      // Simple education hierarchy check
      const eduLevels = ["Below 10th", "10th Pass (SSLC)", "12th Pass (HSC)", "Diploma", "Graduate", "Post Graduate", "PhD"];
      const userEduIdx = eduLevels.indexOf(profile.education);
      const requiredEduIdx = eduLevels.indexOf(exam.qualification_required);
      
      if (userEduIdx < requiredEduIdx) return false;
      if (profile.age > exam.max_age) return false;
      
      return true;
    });

    // 3. AI Enhancement (Optional: Personalized summary)
    let aiAdvice = "";
    try {
      const prompt = `As a career and welfare advisor, I have a user with the following profile:
      Name: ${profile.name}, Age: ${profile.age}, Education: ${profile.education}, Income: ${profile.annualIncome}, Interests: ${profile.interests.join(", ")}.
      
      I have recommended these schemes: ${recommendedSchemes.map(s => s.name).join(", ")}
      And these exams: ${recommendedExams.map(e => e.name).join(", ")}
      
      Provide a 2-sentence encouraging advice for this user.`;
      
      const result = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [{ role: "user", parts: [{ text: prompt }] }]
      });
      aiAdvice = result.text || "";
    } catch (err) {
      console.error("AI Advice failed:", err);
      aiAdvice = "Keep pursuing your goals! You have great potential.";
    }

    res.json({
      schemes: recommendedSchemes,
      exams: recommendedExams,
      advice: aiAdvice
    });
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
